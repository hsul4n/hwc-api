INSERT INTO `medical_diseases` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
('COVID-19', '{\"ar\": \"فيروس كورونا\", \"en\": \"Conronavirus\"}', NULL, '2020-03-21 17:12:15', '2020-03-21 17:12:15');
