INSERT INTO `data_development`.`geo_country_division_levels` (`continent_id`,`country_id`,`level`,`name`,`created_at`,`updated_at`) VALUES 
('AS','YE',1,'{"en":"Governorate","ar":"محافظة"}','2019-10-18 11:01:23','2019-10-18 11:01:23'),
('AS','YE',2,'{"en":"District","ar":"مديرية"}','2019-10-18 11:01:23','2019-10-18 11:01:23'),
('AS','YE',3,'{"en":"''Uzlah","ar":"عزلة"}','2019-10-18 11:01:23','2019-10-18 11:01:23'),
('AS','YE',4,'{"en":"Village","ar":"قرىة"}','2019-10-18 11:01:23','2019-10-18 11:01:23');
